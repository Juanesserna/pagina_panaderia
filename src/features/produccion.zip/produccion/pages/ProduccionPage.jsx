import { useState, useMemo } from 'react'
import { Box, Stack, Typography, IconButton, Divider, Collapse } from '@mui/material'
import { alpha } from '@mui/material/styles'
import {
  IconSearch,
  IconPlus,
  IconMinus,
  IconFilter,
  IconX,
  IconEye,
  IconPencil,
  IconTrash,
  IconChevronDown,
  IconChevronUp,
  IconCircleCheck,
  IconAlertTriangle,
  IconToggleRight,
} from '@tabler/icons-react'
import { Button, DataTable, Input, KPICard, KPIGrid, Modal, Pagination, SearchInput, Select, StatusBadge } from '@shared/ui'
import { PAGE_SIZE, estadoVariant, estadoOptions, origenOptions } from '@features/produccion/constants/produccion.constants'
import {
  cap,
  esEstadoFinal,
  estadoEfectivo,
  totalCantidad,
  formatFecha,
  parseFechaSolicitud,
  siguienteIdOrden,
  calcularInsumos,
  formatCantidadInsumo,
} from '@features/produccion/utils/produccionHelpers'
// TEMPORAL: datos de ejemplo. En el paso de hooks/services esto deja de importarse desde la página.
import { initialOrdenes, usuarioAutenticado, recetasProductos, catalogoProductos } from '@features/produccion/mocks/produccionMockData'

// ---------- Presentación ----------

function FilterLabel({ children }) {
  return (
    <Typography variant="overline" component="div" sx={{ mb: 0.5 }}>
      {children}
    </Typography>
  )
}

// Etiqueta tenue de los modales de detalle (no forma parte del panel de filtros).
function DimLabel({ children, sx }) {
  return (
    <Typography variant="overline" component="div" sx={{ color: 'text.dim', ...sx }}>
      {children}
    </Typography>
  )
}

// Campo de solo lectura (inhabilitado) con la misma apariencia que el resto de campos del modal.
function CampoEstatico({ label, value }) {
  return (
    <Box sx={{ minWidth: 0 }}>
      <FilterLabel>{label}</FilterLabel>
      <Input value={value} onChange={() => {}} disabled />
    </Box>
  )
}

export default function ProduccionPage() {
  const [ordenes, setOrdenes] = useState(initialOrdenes)
  const [search, setSearch] = useState('')
  const [estadoFilter, setEstadoFilter] = useState('')
  const [page, setPage] = useState(1)

  const [showModal, setShowModal] = useState(false)
  const [selected, setSelected] = useState(null)
  const [insumosAbiertos, setInsumosAbiertos] = useState(false)

  const [showFiltros, setShowFiltros] = useState(false)
  const [origenFilter, setOrigenFilter] = useState('')
  const [fechaDesde, setFechaDesde] = useState('')
  const [fechaHasta, setFechaHasta] = useState('')
  const [cantidadMin, setCantidadMin] = useState('')
  const [cantidadMax, setCantidadMax] = useState('')

  const [deleteId, setDeleteId] = useState(null)

  const [estadoEditId, setEstadoEditId] = useState(null)
  const [estadoEditValue, setEstadoEditValue] = useState('pendiente')

  const [showOrderModal, setShowOrderModal] = useState(false)
  const [orderModalMode, setOrderModalMode] = useState('nueva')
  const [editingId, setEditingId] = useState(null)
  const [editingOrden, setEditingOrden] = useState(null)
  const [formItems, setFormItems] = useState([])
  const [productoBusqueda, setProductoBusqueda] = useState('')
  const [formId, setFormId] = useState('')
  const [formFechaSolicitud, setFormFechaSolicitud] = useState('')

  const handleEliminar = (id) => {
    setOrdenes((prev) => prev.filter((o) => o.id !== id))
  }

  const filtered = useMemo(() => {
    let data = ordenes
    if (search) {
      const q = search.toLowerCase()
      data = data.filter(
        (o) =>
          o.producto.toLowerCase().includes(q) ||
          o.id.toLowerCase().includes(q) ||
          o.generadoPor.documento.toLowerCase().includes(q) ||
          o.items.some((i) => i.nombre.toLowerCase().includes(q))
      )
    }
    if (estadoFilter) data = data.filter((o) => estadoEfectivo(o) === estadoFilter)
    if (origenFilter) data = data.filter((o) => o.producto === origenFilter)
    if (fechaDesde) {
      const desde = new Date(`${fechaDesde}T00:00:00`)
      data = data.filter((o) => parseFechaSolicitud(o.fechaSolicitud) >= desde)
    }
    if (fechaHasta) {
      const hasta = new Date(`${fechaHasta}T23:59:59`)
      data = data.filter((o) => parseFechaSolicitud(o.fechaSolicitud) <= hasta)
    }
    if (cantidadMin !== '') {
      const min = parseInt(cantidadMin, 10)
      if (!isNaN(min)) data = data.filter((o) => totalCantidad(o) >= min)
    }
    if (cantidadMax !== '') {
      const max = parseInt(cantidadMax, 10)
      if (!isNaN(max)) data = data.filter((o) => totalCantidad(o) <= max)
    }
    return data
  }, [ordenes, search, estadoFilter, origenFilter, fechaDesde, fechaHasta, cantidadMin, cantidadMax])

  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)

  const filtrosActivos = Boolean(estadoFilter || origenFilter || fechaDesde || fechaHasta || cantidadMin || cantidadMax)
  const cantidadFiltrosActivos = [estadoFilter, origenFilter, fechaDesde, fechaHasta, cantidadMin, cantidadMax].filter(Boolean).length

  const limpiarFiltros = () => {
    setEstadoFilter('')
    setOrigenFilter('')
    setFechaDesde('')
    setFechaHasta('')
    setCantidadMin('')
    setCantidadMax('')
    setPage(1)
  }

  const completados = ordenes.filter((o) => estadoEfectivo(o) === 'completado').length
  const retrasados = ordenes.filter((o) => estadoEfectivo(o) === 'retrasado').length

  // Catálogo filtrado por el buscador
  const productosFiltrados = useMemo(
    () => catalogoProductos.filter((p) => p.toLowerCase().includes(productoBusqueda.toLowerCase())),
    [productoBusqueda]
  )

  const resetFormulario = () => {
    setProductoBusqueda('')
    setFormItems([])
  }

  const handleNuevaOrden = () => {
    setOrderModalMode('nueva')
    setEditingId(null)
    setEditingOrden(null)
    resetFormulario()
    setFormId(siguienteIdOrden(ordenes))
    setFormFechaSolicitud(formatFecha(new Date()))
    setShowOrderModal(true)
  }

  const handleEditar = (orden) => {
    if (esEstadoFinal(orden.estado)) return
    setOrderModalMode('editar')
    setEditingId(orden.id)
    setEditingOrden(orden)
    setProductoBusqueda('')
    setFormItems(orden.items.map((i) => ({ ...i })))
    setShowOrderModal(true)
  }

  const handleVerDetalle = (orden) => {
    setSelected(orden)
    setInsumosAbiertos(false)
    setShowModal(true)
  }

  // Agrega 1 unidad (la cantidad se modifica solo en el resumen). Devuelve true si se agregó.
  const agregarProducto = (nombre) => {
    if (!nombre) return false
    setFormItems((prev) => {
      const existente = prev.find((i) => i.nombre === nombre)
      if (existente) {
        return prev.map((i) => (i.nombre === nombre ? { ...i, cantidad: i.cantidad + 1 } : i))
      }
      return [...prev, { nombre, cantidad: 1 }]
    })
    return true
  }

  // Agrega el primer producto que coincide con la búsqueda
  const handleAgregarProducto = () => {
    if (agregarProducto(productosFiltrados[0])) setProductoBusqueda('')
  }

  const handleQuitarProducto = (nombre) => {
    setFormItems((prev) => prev.filter((i) => i.nombre !== nombre))
  }

  const handleActualizarCantidad = (nombre, nuevaCantidad) => {
    if (nuevaCantidad <= 0) {
      handleQuitarProducto(nombre)
      return
    }
    setFormItems((prev) => prev.map((i) => (i.nombre === nombre ? { ...i, cantidad: nuevaCantidad } : i)))
  }

  const handleConfirmarOrden = () => {
    if (formItems.length === 0) return
    if (orderModalMode === 'nueva') {
      const nuevaOrden = {
        id: formId,
        producto: 'Manual',
        items: formItems,
        unidad: 'piezas',
        fechaSolicitud: formFechaSolicitud,
        fechaFabricacion: '',
        estado: 'pendiente',
        generadoPor: { nombre: usuarioAutenticado.nombre, documento: usuarioAutenticado.nit },
      }
      setOrdenes((prev) => [nuevaOrden, ...prev])
    } else if (editingId) {
      setOrdenes((prev) =>
        prev.map((o) => {
          if (o.id !== editingId) return o
          if (esEstadoFinal(o.estado)) return o
          return { ...o, items: formItems }
        })
      )
    }
    setShowOrderModal(false)
  }

  const handleAbrirCambioEstado = (orden) => {
    if (esEstadoFinal(orden.estado)) return
    setEstadoEditId(orden.id)
    setEstadoEditValue(estadoEfectivo(orden))
  }

  const handleConfirmarEstado = () => {
    if (!estadoEditId) return
    setOrdenes((prev) =>
      prev.map((o) => {
        if (o.id !== estadoEditId) return o
        if (esEstadoFinal(o.estado)) return o
        return {
          ...o,
          estado: estadoEditValue,
          fechaFabricacion: estadoEditValue === 'completado' && !o.fechaFabricacion ? formatFecha(new Date()) : o.fechaFabricacion,
        }
      })
    )
    setEstadoEditId(null)
  }

  const estadoEditandoLabel = editingOrden ? cap(estadoEfectivo(editingOrden)) : ''

  const columns = [
    {
      key: 'id',
      header: 'Orden',
      accessor: (r) => (
        <Typography variant="mono" sx={{ color: 'text.secondary' }}>
          {r.id}
        </Typography>
      ),
    },
    {
      key: 'documento',
      header: 'NIT/Cédula',
      accessor: (r) => (
        <Typography variant="caption" sx={{ color: 'text.secondary' }}>
          {r.generadoPor.documento}
        </Typography>
      ),
    },
    {
      key: 'fechaSolicitud',
      header: 'Fecha solicitud',
      accessor: (r) => (
        <Typography variant="caption" sx={{ color: 'text.secondary' }}>
          {r.fechaSolicitud}
        </Typography>
      ),
    },
    {
      key: 'fechaFabricacion',
      header: 'Fecha fabricación',
      accessor: (r) =>
        r.fechaFabricacion ? (
          <Typography variant="caption" sx={{ color: 'text.secondary' }}>
            {r.fechaFabricacion}
          </Typography>
        ) : (
          <Typography variant="caption" sx={{ fontStyle: 'italic', color: 'text.dim', opacity: 0.3 }}>
            Por definir
          </Typography>
        ),
    },
    {
      key: 'estado',
      header: 'Estado',
      accessor: (r) => {
        const efectivo = estadoEfectivo(r)
        const bloqueado = esEstadoFinal(r.estado)
        return (
          <Stack direction="row" alignItems="center" spacing={0.75}>
            <StatusBadge variant={estadoVariant[efectivo]} dot>
              {cap(efectivo)}
            </StatusBadge>
            <IconButton
              size="small"
              disabled={bloqueado}
              title={bloqueado ? 'Estado final, no editable' : 'Cambiar estado'}
              onClick={(e) => {
                e.stopPropagation()
                handleAbrirCambioEstado(r)
              }}
              sx={{ color: 'text.secondary' }}
            >
              <IconToggleRight size={15} />
            </IconButton>
          </Stack>
        )
      },
    },
    {
      key: 'acciones',
      header: '',
      align: 'right',
      accessor: (r) => {
        const bloqueado = esEstadoFinal(r.estado)
        return (
          <Stack direction="row" alignItems="center" justifyContent="flex-end" spacing={0.5}>
            <IconButton
              size="small"
              title="Ver detalle"
              onClick={(e) => {
                e.stopPropagation()
                handleVerDetalle(r)
              }}
              sx={{ color: 'text.secondary' }}
            >
              <IconEye size={15} />
            </IconButton>
            <IconButton
              size="small"
              disabled={bloqueado}
              title={bloqueado ? 'Esta orden ya no se puede editar' : 'Editar orden'}
              onClick={(e) => {
                e.stopPropagation()
                handleEditar(r)
              }}
              sx={{ color: 'text.secondary' }}
            >
              <IconPencil size={15} />
            </IconButton>
            <IconButton
              size="small"
              title="Eliminar orden"
              onClick={(e) => {
                e.stopPropagation()
                setDeleteId(r.id)
              }}
              sx={{ color: 'error.main' }}
            >
              <IconTrash size={15} />
            </IconButton>
          </Stack>
        )
      },
    },
  ]

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
      {/* KPIs */}
      <KPIGrid>
        <KPICard title="Órdenes completadas" value={completados} icon={<IconCircleCheck size={16} />} variant="success" />
        <KPICard title="Retrasadas" value={retrasados} icon={<IconAlertTriangle size={16} />} variant="danger" />
      </KPIGrid>

      <Box sx={{ borderRadius: 2.5, overflow: 'hidden', bgcolor: 'background.paper', border: '1px solid', borderColor: 'divider' }}>
        {/* Toolbar */}
        <Stack direction="row" flexWrap="wrap" alignItems="center" sx={{ px: 2.5, py: 2 }}>
          <Typography variant="h6" sx={{ mr: 'auto' }}>
            Órdenes de producción
          </Typography>

          <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1.25 }}>
            <SearchInput
              placeholder="Buscar orden, NIT o producto…"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value)
                setPage(1)
              }}
            />

            <Button size="toolbar" leftIcon={<IconPlus size={13} />} onClick={handleNuevaOrden}>
              Nueva orden
            </Button>

            <Button
              variant={filtrosActivos ? 'primary' : 'secondary'}
              size="toolbar"
              leftIcon={<IconFilter size={13} />}
              onClick={() => setShowFiltros((v) => !v)}
            >
              Filtrar
              {filtrosActivos && (
                <Box
                  component="span"
                  sx={{
                    ml: 0.75,
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: 16,
                    width: 16,
                    borderRadius: '50%',
                    typography: 'overline',
                    bgcolor: (t) => alpha(t.palette.common.white, 0.3),
                    color: 'inherit',
                  }}
                >
                  {cantidadFiltrosActivos}
                </Box>
              )}
            </Button>
          </Box>
        </Stack>

        <Divider />

        {/* Filtros */}
        <Collapse in={showFiltros}>
          <Stack
            direction="row"
            flexWrap="wrap"
            alignItems="flex-end"
            sx={{ gap: 2.5, px: 2.5, py: 2, borderBottom: '1px solid', borderColor: 'divider', bgcolor: 'action.hover' }}
          >
            <Box sx={{ width: 144 }}>
              <FilterLabel>Estado</FilterLabel>
              <Select
                options={[{ value: '', label: 'Todos' }, ...estadoOptions]}
                value={estadoFilter}
                onChange={(e) => {
                  setEstadoFilter(e.target.value)
                  setPage(1)
                }}
              />
            </Box>

            <Box sx={{ width: 144 }}>
              <FilterLabel>Origen</FilterLabel>
              <Select
                options={[{ value: '', label: 'Todos' }, ...origenOptions]}
                value={origenFilter}
                onChange={(e) => {
                  setOrigenFilter(e.target.value)
                  setPage(1)
                }}
              />
            </Box>

            <Box sx={{ width: 144 }}>
              <FilterLabel>Desde</FilterLabel>
              <Input
                type="date"
                value={fechaDesde}
                onChange={(e) => {
                  setFechaDesde(e.target.value)
                  setPage(1)
                }}
              />
            </Box>

            <Box sx={{ width: 144 }}>
              <FilterLabel>Hasta</FilterLabel>
              <Input
                type="date"
                value={fechaHasta}
                onChange={(e) => {
                  setFechaHasta(e.target.value)
                  setPage(1)
                }}
              />
            </Box>

            <Box sx={{ width: 112 }}>
              <FilterLabel>Cantidad mín.</FilterLabel>
              <Input
                type="number"
                min={0}
                placeholder="0"
                value={cantidadMin}
                onChange={(e) => {
                  setCantidadMin(e.target.value)
                  setPage(1)
                }}
              />
            </Box>

            <Box sx={{ width: 112 }}>
              <FilterLabel>Cantidad máx.</FilterLabel>
              <Input
                type="number"
                min={0}
                placeholder="Sin límite"
                value={cantidadMax}
                onChange={(e) => {
                  setCantidadMax(e.target.value)
                  setPage(1)
                }}
              />
            </Box>

            {filtrosActivos && (
              <Button variant="ghost" size="sm" onClick={limpiarFiltros}>
                Limpiar filtros
              </Button>
            )}
          </Stack>
        </Collapse>

        {/* Tabla */}
        <DataTable columns={columns} data={paginated} keyExtractor={(r) => r.id} emptyMessage="Sin órdenes encontradas" />
        <Box sx={{ px: 2.5, borderTop: '1px solid', borderColor: 'divider' }}>
          <Pagination page={page} total={filtered.length} pageSize={PAGE_SIZE} onPageChange={setPage} />
        </Box>
      </Box>

      {/* Modal: Ver detalle */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title={`Detalle orden ${selected?.id ?? ''}`} size="md" showDivider>
        {selected &&
          (() => {
            const insumos = calcularInsumos(selected.items, recetasProductos)
            const efectivo = estadoEfectivo(selected)
            const detalleItems = [
              ...(selected.producto !== 'Manual' && selected.ventaId ? [{ label: 'Venta relacionada', value: selected.ventaId }] : []),
              { label: 'Cantidad', value: `${totalCantidad(selected)}${selected.unidad !== 'piezas' ? ` ${selected.unidad}` : ''}` },
              { label: 'Fecha solicitud', value: selected.fechaSolicitud },
              { label: 'Fecha fabricación', value: selected.fechaFabricacion || 'Por definir' },
              { label: 'Generado por', value: selected.generadoPor.nombre },
              { label: 'NIT/Cédula', value: selected.generadoPor.documento },
            ]
            return (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 1.5 }}>
                  {detalleItems.map((item) => (
                    <Box
                      key={item.label}
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 0.5,
                        borderRadius: 1.5,
                        p: 1.5,
                        border: '1px solid',
                        borderColor: 'divider',
                        bgcolor: 'background.alt',
                      }}
                    >
                      <DimLabel>{item.label}</DimLabel>
                      <Typography variant="subtitle1">
                        {item.label === 'Fecha fabricación' && !selected.fechaFabricacion ? (
                          <Box component="span" sx={{ fontStyle: 'italic', opacity: 0.55 }}>
                            {item.value}
                          </Box>
                        ) : (
                          item.value
                        )}
                      </Typography>
                    </Box>
                  ))}
                </Box>

                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                  <DimLabel>Productos asociados</DimLabel>
                  <Box sx={{ display: 'flex', flexDirection: 'column', borderRadius: 1.5, overflow: 'hidden', border: '1px solid', borderColor: 'divider' }}>
                    {selected.items.map((item, idx) => (
                      <Box
                        key={idx}
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          px: 1.5,
                          py: 1,
                          bgcolor: 'background.alt',
                          borderTop: idx > 0 ? '1px solid' : 'none',
                          borderColor: 'divider',
                        }}
                      >
                        <Typography variant="body1" sx={{ color: 'text.primary' }}>
                          {item.nombre}
                        </Typography>
                        <Typography variant="body1" sx={{ color: 'text.secondary' }}>
                          {item.cantidad}
                          {selected.unidad !== 'piezas' ? ` ${selected.unidad}` : ''}
                        </Typography>
                      </Box>
                    ))}
                  </Box>
                </Box>

                {insumos.length > 0 && (
                  <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                    <Box
                      component="button"
                      type="button"
                      onClick={() => setInsumosAbiertos((v) => !v)}
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        borderRadius: 1.5,
                        px: 1.5,
                        py: 1.25,
                        bgcolor: 'background.alt',
                        border: '1px solid',
                        borderColor: 'divider',
                        color: 'text.secondary',
                        cursor: 'pointer',
                        '&:hover': { opacity: 0.9 },
                      }}
                    >
                      <DimLabel sx={{ color: 'text.secondary' }}>Insumos requeridos ({insumos.length})</DimLabel>
                      {insumosAbiertos ? <IconChevronUp size={15} /> : <IconChevronDown size={15} />}
                    </Box>
                    {insumosAbiertos && (
                      <Box sx={{ display: 'flex', flexDirection: 'column', borderRadius: 1.5, overflow: 'hidden', border: '1px solid', borderColor: 'divider' }}>
                        {insumos.map((insumo, idx) => (
                          <Box
                            key={insumo.nombre}
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              px: 1.5,
                              py: 1,
                              bgcolor: 'background.alt',
                              borderTop: idx > 0 ? '1px solid' : 'none',
                              borderColor: 'divider',
                            }}
                          >
                            <Typography variant="body1" sx={{ color: 'text.primary' }}>
                              {insumo.nombre}
                            </Typography>
                            <Typography variant="mono" sx={{ color: 'text.secondary' }}>
                              {formatCantidadInsumo(insumo.cantidad)} {insumo.unidad}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    )}
                  </Box>
                )}

                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Typography variant="body1" sx={{ color: 'text.secondary' }}>
                    Estado:
                  </Typography>
                  <StatusBadge variant={estadoVariant[efectivo]} dot>
                    {cap(efectivo)}
                  </StatusBadge>
                </Box>

                <Stack direction="row" justifyContent="flex-end" spacing={1}>
                  <Button variant="secondary" size="sm" onClick={() => setShowModal(false)}>
                    Cerrar
                  </Button>
                </Stack>
              </Box>
            )
          })()}
      </Modal>

      {/* Modal: Nueva orden / Editar (master-detail) */}
      <Modal
        open={showOrderModal}
        onClose={() => setShowOrderModal(false)}
        title={orderModalMode === 'nueva' ? 'Nueva orden' : `Editar orden ${editingId}`}
        size="lg"
        showDivider
        sx={{ width: '100%', maxWidth: 1100, minHeight: 600 }}
      >
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, mt: '20px' }}>
          {/* Parte superior: ID, fechas, estado, generado por y NIT/Cédula */}
          <Box
            sx={{
              display: 'grid',
              gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: 'repeat(auto-fit, minmax(150px, 1fr))' },
              gap: 2,
              alignItems: 'end',
            }}
          >
            {orderModalMode === 'nueva' && (
              <>
                <CampoEstatico label="ID de orden" value={formId} />
                <CampoEstatico label="Fecha solicitud" value={formFechaSolicitud} />
                <CampoEstatico label="Fecha fabricación" value="Por definir" />
                <CampoEstatico label="Estado" value="Pendiente" />
                <CampoEstatico label="NIT/Cédula" value={usuarioAutenticado.nit} />
                <CampoEstatico label="Generado por" value={usuarioAutenticado.nombre} />
              </>
            )}

            {orderModalMode === 'editar' && editingOrden && (
              <>
                <CampoEstatico label="ID de orden" value={editingOrden.id} />
                <CampoEstatico label="Fecha solicitud" value={editingOrden.fechaSolicitud} />
                <CampoEstatico label="Fecha fabricación" value={editingOrden.fechaFabricacion || 'Por definir'} />
                <CampoEstatico label="Estado" value={estadoEditandoLabel} />
                <CampoEstatico label="NIT/Cédula" value={editingOrden.generadoPor.documento} />
                <CampoEstatico
                  label={editingOrden.producto === 'Pagina' ? 'Solicitado por' : 'Generado por'}
                  value={editingOrden.generadoPor.nombre}
                />
                {editingOrden.producto === 'Pagina' && editingOrden.ventaId && (
                  <CampoEstatico label="Venta relacionada" value={editingOrden.ventaId} />
                )}
              </>
            )}
          </Box>

          <Divider />

          {/* Master-detail: catálogo (izquierda) + resumen (derecha) */}
          <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: '1.15fr 1fr' }, gap: 2.5, alignItems: 'stretch' }}>
            {/* Catálogo de productos */}
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.25, minWidth: 0 }}>
              <FilterLabel>Catálogo de productos</FilterLabel>
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))',
                  gap: 1.25,
                  border: '1px solid',
                  borderColor: 'divider',
                  borderRadius: 1.5,
                  p: 1.25,
                  minHeight: 180,
                  maxHeight: 380,
                  overflowY: 'auto',
                }}
              >
                {productosFiltrados.map((nombre) => (
                  <Box
                    key={nombre}
                    component="button"
                    type="button"
                    onClick={() => agregarProducto(nombre)}
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'flex-start',
                      gap: 0.75,
                      p: 1.25,
                      font: 'inherit',
                      color: 'text.primary',
                      textAlign: 'left',
                      cursor: 'pointer',
                      borderRadius: 1.5,
                      border: '1px solid',
                      borderColor: 'divider',
                      bgcolor: 'background.alt',
                      '&:hover': { borderColor: 'primary.main' },
                    }}
                  >
                    <Box sx={{ width: 44, height: 44, borderRadius: 1, bgcolor: 'action.hover', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Typography variant="h6" sx={{ color: 'text.secondary' }}>
                        {nombre.charAt(0)}
                      </Typography>
                    </Box>
                    <Typography variant="body2">{nombre}</Typography>
                  </Box>
                ))}
                {productosFiltrados.length === 0 && (
                  <Box sx={{ gridColumn: '1 / -1', display: 'flex', alignItems: 'center', justifyContent: 'center', py: 5 }}>
                    <Typography variant="body1" sx={{ color: 'text.secondary' }}>
                      Sin productos que coincidan
                    </Typography>
                  </Box>
                )}
              </Box>

              {/* Buscar producto (debajo del catálogo) */}
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Input
                    placeholder="Buscar producto…"
                    value={productoBusqueda}
                    onChange={(e) => setProductoBusqueda(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault()
                        if (productoBusqueda.trim() && productosFiltrados.length > 0) handleAgregarProducto()
                      }
                    }}
                    leftIcon={<IconSearch size={13} />}
                  />
                </Box>
              </Box>
            </Box>

            {/* Resumen (único lugar donde se modifica la cantidad) */}
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1.5, minWidth: 0 }}>
              <FilterLabel>Resumen</FilterLabel>
              <Box sx={{ display: 'flex', flexDirection: 'column', borderRadius: 1.5, overflowY: 'auto', minHeight: 180, maxHeight: 380, flexGrow: 1, border: '1px solid', borderColor: 'divider' }}>
                {formItems.length === 0 ? (
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 4, px: 1.5, textAlign: 'center' }}>
                    <Typography variant="body1" sx={{ color: 'text.dim' }}>
                      Sin productos agregados
                    </Typography>
                  </Box>
                ) : (
                  formItems.map((item, idx) => (
                    <Box
                      key={item.nombre}
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 0.75,
                        px: 1.5,
                        py: 1,
                        bgcolor: 'background.alt',
                        borderTop: idx > 0 ? '1px solid' : 'none',
                        borderColor: 'divider',
                      }}
                    >
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1 }}>
                        <Typography variant="body1" noWrap sx={{ color: 'text.primary' }}>
                          {item.nombre}
                        </Typography>
                        <IconButton size="small" onClick={() => handleQuitarProducto(item.nombre)} aria-label={`Quitar ${item.nombre}`} sx={{ color: 'text.dim' }}>
                          <IconX size={14} />
                        </IconButton>
                      </Box>

                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                        <Box
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            borderRadius: 1,
                            overflow: 'hidden',
                            border: '1px solid',
                            borderColor: 'divider',
                          }}
                        >
                          <IconButton
                            size="small"
                            onClick={() => handleActualizarCantidad(item.nombre, item.cantidad - 1)}
                            aria-label={`Disminuir cantidad de ${item.nombre}`}
                            sx={{ height: 24, width: 24, borderRadius: 0, color: 'text.secondary' }}
                          >
                            <IconMinus size={12} />
                          </IconButton>
                          <Typography variant="body1" sx={{ width: 28, textAlign: 'center', color: 'text.primary' }}>
                            {item.cantidad}
                          </Typography>
                          <IconButton
                            size="small"
                            onClick={() => handleActualizarCantidad(item.nombre, item.cantidad + 1)}
                            aria-label={`Aumentar cantidad de ${item.nombre}`}
                            sx={{ height: 24, width: 24, borderRadius: 0, color: 'text.secondary' }}
                          >
                            <IconPlus size={12} />
                          </IconButton>
                        </Box>
                      </Box>
                    </Box>
                  ))
                )}
              </Box>
              <Button variant="primary" size="sm" fullWidth disabled={formItems.length === 0} onClick={handleConfirmarOrden}>
                Ordenar
              </Button>
            </Box>
          </Box>

          <Stack direction="row" justifyContent="flex-end" spacing={1}>
            <Button variant="secondary" size="sm" onClick={() => setShowOrderModal(false)}>
              Cancelar
            </Button>
          </Stack>
        </Box>
      </Modal>

      {/* Modal: Cambiar estado desde el listado */}
      <Modal open={!!estadoEditId} onClose={() => setEstadoEditId(null)} title={`Cambiar estado ${estadoEditId ?? ''}`} size="sm" showDivider>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.5 }}>
            <FilterLabel>Estado</FilterLabel>
            <Select options={estadoOptions} value={estadoEditValue} onChange={(e) => setEstadoEditValue(e.target.value)} />
          </Box>
          {estadoEditValue === 'retrasado' && (
            <Typography variant="caption" sx={{ color: 'text.dim' }}>
              Nota: el estado "retrasado" también se aplica automáticamente cuando han pasado 2 días desde la fecha de
              solicitud.
            </Typography>
          )}
          <Stack direction="row" justifyContent="flex-end" spacing={1}>
            <Button variant="secondary" size="sm" onClick={() => setEstadoEditId(null)}>
              Cancelar
            </Button>
            <Button variant="primary" size="sm" onClick={handleConfirmarEstado}>
              Guardar
            </Button>
          </Stack>
        </Box>
      </Modal>

      {/* Confirmación de eliminación */}
      <Modal open={!!deleteId} onClose={() => setDeleteId(null)} title="Eliminar orden" size="sm" showDivider>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Typography variant="body1" sx={{ color: 'text.secondary' }}>
            ¿Seguro que deseas eliminar la orden{' '}
            <Typography variant="mono" component="span" sx={{ color: 'text.primary' }}>
              {deleteId}
            </Typography>
            ? Esta acción no se puede deshacer.
          </Typography>
          <Stack direction="row" justifyContent="flex-end" spacing={1}>
            <Button variant="secondary" size="sm" onClick={() => setDeleteId(null)}>
              Cancelar
            </Button>
            <Button
              variant="danger"
              size="sm"
              onClick={() => {
                if (deleteId) handleEliminar(deleteId)
                setDeleteId(null)
              }}
            >
              Eliminar
            </Button>
          </Stack>
        </Box>
      </Modal>

      <Typography
        variant="caption"
        component="footer"
        sx={{ display: 'block', pt: 2, pb: 2, borderTop: '1px solid', borderColor: 'divider', textAlign: 'center', color: 'text.dim' }}
      >
        © 2026 Al Horno. Todos los derechos reservados a la institución educativa SENA
      </Typography>
    </Box>
  )
}
