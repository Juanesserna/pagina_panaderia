// Exporta lo que otros features puedan necesitar de shared/components
export { KPICard } from "./KPICard";
export { StatusBadge } from "./StatusBadge";
export { FormField, fieldInputSx } from "./FormField";
export {
    tableSx,
    tableHeadCellSx,
    tableBodyCellSx,
    codigoCellSx,
    nombreCellSx,
    monoCellSx,
    linkCellSx,
    accionIconSx,
    paginationSx,
} from "./tableStyles";
export { filtrosPanelSx, filtroFieldSx } from "./filtrosPanelStyles";
