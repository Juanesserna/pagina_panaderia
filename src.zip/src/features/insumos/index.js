// src/features/insumos/index.js
<<<<<<< HEAD
export { default as InsumosPage } from "./pages/InsumosPage";
export { useInsumos, filtrosVacios } from "./hooks/useInsumos";
export { InsumosKpis } from "./components/InsumosKpis";
export { InsumosTable } from "./components/InsumosTable";
export { FormularioInsumo } from "./components/FormularioInsumo";
export { DetalleInsumo } from "./components/DetalleInsumo";
export { FiltrosInsumosPanel } from "./components/FiltrosInsumosPanel";
=======
export { default as InsumosPage } from './pages/InsumosPage'
export { useInsumos, filtrosVacios } from './hooks/useInsumos'
export { InsumosKpis } from './components/InsumosKpis'
export { InsumosTable } from './components/InsumosTable'
export { FormularioInsumo } from './components/FormularioInsumo'
export { DetalleInsumo } from './components/DetalleInsumo'
export { FiltrosInsumosPanel } from './components/FiltrosInsumosPanel'
>>>>>>> a0bd307af696e1bcc5724fb95b6a709de9919996
