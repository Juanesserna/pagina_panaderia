<<<<<<< HEAD
import { Box, Button, MenuItem, TextField } from "@mui/material";
import { FormField, filtrosPanelSx, filtroFieldSx } from "@shared/components";
import { getCategorias, getUnidadesMedida } from "../services/insumosService";

const NIVELES_STOCK = [
    { value: "", label: "Todos" },
    { value: "bajo", label: "Stock Bajo" },
    { value: "normal", label: "Stock Normal" },
    { value: "sin", label: "Sin Stock" },
];

/**
 * Filtros en línea, debajo del toolbar de la tabla (no lateral, no drawer).
 * Aplica en vivo: cada cambio actualiza filtrosActivos directamente,
 * mismo patrón y estilo que FiltrosProveedoresPanel.
 */
export function FiltrosInsumosPanel({ filtrosActivos, onChange, onLimpiar }) {
    const categorias = getCategorias();
    const unidades = getUnidadesMedida();
    const set = (campo) => (e) => onChange({ ...filtrosActivos, [campo]: e.target.value });

    return (
        <Box sx={filtrosPanelSx}>
            <Box sx={{ flex: "1 1 170px", minWidth: 150 }}>
                <FormField label="Categoría">
                    <TextField
                        select
                        size="small"
                        fullWidth
                        value={filtrosActivos.idCategoria}
                        onChange={set("idCategoria")}
                        sx={filtroFieldSx}
                    >
                        <MenuItem value="">Todas</MenuItem>
                        {categorias.map((c) => (
                            <MenuItem key={c.id} value={c.id}>
                                {c.nombre}
                            </MenuItem>
                        ))}
                    </TextField>
                </FormField>
            </Box>

            <Box sx={{ flex: "1 1 130px", minWidth: 110 }}>
                <FormField label="Estado">
                    <TextField
                        select
                        size="small"
                        fullWidth
                        value={filtrosActivos.estado}
                        onChange={set("estado")}
                        sx={filtroFieldSx}
                    >
                        <MenuItem value="">Todos</MenuItem>
                        <MenuItem value="true">Activo</MenuItem>
                        <MenuItem value="false">Inactivo</MenuItem>
                    </TextField>
                </FormField>
            </Box>

            <Box sx={{ flex: "1 1 150px", minWidth: 130 }}>
                <FormField label="Nivel de stock">
                    <TextField
                        select
                        size="small"
                        fullWidth
                        value={filtrosActivos.nivelStock}
                        onChange={set("nivelStock")}
                        sx={filtroFieldSx}
                    >
                        {NIVELES_STOCK.map((n) => (
                            <MenuItem key={n.value || "todos"} value={n.value}>
                                {n.label}
                            </MenuItem>
                        ))}
                    </TextField>
                </FormField>
            </Box>

            <Box sx={{ flex: "1 1 130px", minWidth: 110 }}>
                <FormField label="Unidad">
                    <TextField
                        select
                        size="small"
                        fullWidth
                        value={filtrosActivos.idUnidadMedida}
                        onChange={set("idUnidadMedida")}
                        sx={filtroFieldSx}
                    >
                        <MenuItem value="">Todas</MenuItem>
                        {unidades.map((u) => (
                            <MenuItem key={u.id} value={u.id}>
                                {u.abreviatura}
                            </MenuItem>
                        ))}
                    </TextField>
                </FormField>
            </Box>

            <Box sx={{ flex: "1 1 110px", minWidth: 100 }}>
                <FormField label="Stock mín.">
                    <TextField
                        type="number"
                        size="small"
                        fullWidth
                        placeholder="0"
                        value={filtrosActivos.stockMinimoDesde}
                        onChange={set("stockMinimoDesde")}
                        sx={filtroFieldSx}
                    />
                </FormField>
            </Box>

            <Box sx={{ flex: "1 1 110px", minWidth: 100 }}>
                <FormField label="Stock máx.">
                    <TextField
                        type="number"
                        size="small"
                        fullWidth
                        placeholder="Sin límite"
                        value={filtrosActivos.stockMinimoHasta}
                        onChange={set("stockMinimoHasta")}
                        sx={filtroFieldSx}
                    />
                </FormField>
            </Box>

            <Button variant="text" size="small" onClick={onLimpiar} sx={{ mb: 0.5, whiteSpace: "nowrap" }}>
                Limpiar filtros
            </Button>
        </Box>
    );
=======
import { Stack, Box } from '@mui/material'
import { Select } from '@features/produccion/components/Select'
import { Input } from '@features/produccion/components/Input'
import { Button } from '@features/produccion/components/Button'
import { Campo } from './Campo'
import { getCategorias, getUnidadesMedida } from '../services/insumosService'

const NIVELES_STOCK = [
  { value: '', label: 'Todos' },
  { value: 'bajo', label: 'Stock bajo' },
  { value: 'normal', label: 'Stock normal' },
  { value: 'sin', label: 'Sin stock' },
]

export function FiltrosInsumosPanel({ filtrosActivos, onChange, onLimpiar }) {
  const categorias = getCategorias()
  const unidades = getUnidadesMedida()
  const set = (campo) => (e) => onChange({ ...filtrosActivos, [campo]: e.target.value })

  return (
    <Stack
      direction="row"
      flexWrap="wrap"
      alignItems="flex-end"
      sx={{
        px: 2.5,
        py: 1.5,
        borderBottom: '1px solid',
        borderColor: 'divider',
        bgcolor: 'background.alt',
        gap: 3.5,
        columnGap: 3.5,
        rowGap: 2,
      }}
    >
      <Campo label="Categoría">
        <Box sx={{ width: 160 }}>
          <Select
            options={[{ value: '', label: 'Todas' }, ...categorias.map((c) => ({ value: c.id, label: c.nombre }))]}
            value={filtrosActivos.idCategoria}
            onChange={set('idCategoria')}
          />
        </Box>
      </Campo>

      <Campo label="Estado">
        <Box sx={{ width: 144 }}>
          <Select
            options={[
              { value: '', label: 'Todos' },
              { value: 'true', label: 'Activo' },
              { value: 'false', label: 'Inactivo' },
            ]}
            value={filtrosActivos.estado}
            onChange={set('estado')}
          />
        </Box>
      </Campo>

      <Campo label="Nivel de stock">
        <Box sx={{ width: 144 }}>
          <Select options={NIVELES_STOCK} value={filtrosActivos.nivelStock} onChange={set('nivelStock')} />
        </Box>
      </Campo>

      <Campo label="Unidad">
        <Box sx={{ width: 112 }}>
          <Select
            options={[{ value: '', label: 'Todas' }, ...unidades.map((u) => ({ value: u.id, label: u.abreviatura }))]}
            value={filtrosActivos.idUnidadMedida}
            onChange={set('idUnidadMedida')}
          />
        </Box>
      </Campo>

      <Campo label="Stock mín.">
        <Box sx={{ width: 112 }}>
          <Input type="number" min={0} placeholder="0" value={filtrosActivos.stockMinimoDesde} onChange={set('stockMinimoDesde')} />
        </Box>
      </Campo>

      <Campo label="Stock máx.">
        <Box sx={{ width: 112 }}>
          <Input type="number" min={0} placeholder="Sin límite" value={filtrosActivos.stockMinimoHasta} onChange={set('stockMinimoHasta')} />
        </Box>
      </Campo>

      <Button variant="ghost" size="sm" onClick={onLimpiar}>
        Limpiar filtros
      </Button>
    </Stack>
  )
>>>>>>> a0bd307af696e1bcc5724fb95b6a709de9919996
}
