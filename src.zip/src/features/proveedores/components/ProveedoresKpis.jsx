<<<<<<< HEAD
import { Grid } from "@mui/material";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import { KPICard } from "@shared/components";

/**
 * Tres KPIs en fila (Total / Activos / Inactivos), igual que en Figma.
 * Usa la API nueva de Grid (size={{...}}) — la misma que usa InsumosKpis.
 */
export function ProveedoresKpis({ kpis }) {
    return (
        <Grid container spacing={2}>
            <Grid size={{ xs: 12, sm: 4 }}>
                <KPICard title="Total Proveedores" value={kpis.total} icon={<LocalShippingIcon />} variant="accent" />
            </Grid>
            <Grid size={{ xs: 6, sm: 4 }}>
                <KPICard title="Activos" value={kpis.activos} icon={<CheckCircleIcon />} variant="success" />
            </Grid>
            <Grid size={{ xs: 6, sm: 4 }}>
                <KPICard title="Inactivos" value={kpis.inactivos} icon={<CancelIcon />} variant="danger" />
            </Grid>
        </Grid>
    );
=======
import { Box } from '@mui/material'
import { IconTruck, IconCircleCheck, IconCircleX } from '@tabler/icons-react'
import { KPICard } from '@features/produccion/components/KPICard'

export function ProveedoresKpis({ kpis }) {
  return (
    <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(3, 1fr)' }, gap: 2 }}>
      <KPICard title="Total proveedores" value={kpis.total} icon={<IconTruck size={16} />} variant="accent" />
      <KPICard title="Activos" value={kpis.activos} icon={<IconCircleCheck size={16} />} variant="success" />
      <KPICard title="Inactivos" value={kpis.inactivos} icon={<IconCircleX size={16} />} variant="danger" />
    </Box>
  )
>>>>>>> a0bd307af696e1bcc5724fb95b6a709de9919996
}
