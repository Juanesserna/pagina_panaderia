<<<<<<< HEAD
import {
    Table,
    TableHead,
    TableBody,
    TableRow,
    TableCell,
    TableSortLabel,
    IconButton,
    Stack,
    Typography,
    Box,
} from "@mui/material";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import ToggleOnOutlinedIcon from "@mui/icons-material/ToggleOnOutlined";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import {
    StatusBadge,
    tableSx,
    tableHeadCellSx,
    tableBodyCellSx,
    codigoCellSx,
    nombreCellSx,
    monoCellSx,
    linkCellSx,
    accionIconSx,
} from "@shared/components";
import { formatoCodigo, getEstadoVisual, estadoVisualVariant } from "../utils/proveedoresHelpers";

const COLUMNS = [
    { key: "id", label: "Código", sortable: true },
    { key: "nombre", label: "Nombre Empresa", sortable: true },
    { key: "nit", label: "NIT" },
    { key: "nombreContacto", label: "Contacto" },
    { key: "telefono", label: "Teléfono" },
    { key: "email", label: "Correo" },
    { key: "estado", label: "Estado" },
    { key: "acciones", label: "", align: "right" },
];

export function ProveedoresTable({
    rows,
    sortKey,
    sortDir,
    onSort,
    onVer,
    onEditar,
    onCambiarEstado,
    onEliminar,
}) {
    if (rows.length === 0) {
        return (
            <Box sx={{ py: 8, textAlign: "center" }}>
                <Typography color="text.secondary" variant="body2">
                    Sin proveedores encontrados
                </Typography>
            </Box>
        );
    }

    return (
        <Box sx={{ overflowX: "auto" }}>
            <Table size="small" sx={tableSx}>
                <TableHead>
                    <TableRow>
                        {COLUMNS.map((col) => (
                            <TableCell key={col.key} align={col.align ?? "left"} sx={tableHeadCellSx}>
                                {col.sortable ? (
                                    <TableSortLabel
                                        active={sortKey === col.key}
                                        direction={sortKey === col.key ? sortDir : "asc"}
                                        onClick={() => onSort(col.key)}
                                    >
                                        {col.label}
                                    </TableSortLabel>
                                ) : (
                                    col.label
                                )}
                            </TableCell>
                        ))}
                    </TableRow>
                </TableHead>

                <TableBody>
                    {rows.map((r) => {
                        const ev = getEstadoVisual(r);
                        return (
                            <TableRow key={r.id} hover>
                                <TableCell sx={codigoCellSx}>{formatoCodigo(r.id)}</TableCell>
                                <TableCell sx={nombreCellSx}>{r.nombre}</TableCell>
                                <TableCell sx={monoCellSx}>{r.nit}</TableCell>
                                <TableCell sx={{ ...tableBodyCellSx, whiteSpace: "nowrap" }}>
                                    {r.nombreContacto}
                                </TableCell>
                                <TableCell sx={{ ...tableBodyCellSx, whiteSpace: "nowrap" }}>{r.telefono}</TableCell>
                                <TableCell sx={linkCellSx}>{r.email}</TableCell>
                                <TableCell sx={tableBodyCellSx}>
                                    <StatusBadge variant={estadoVisualVariant[ev]}>{ev}</StatusBadge>
                                </TableCell>
                                <TableCell align="right" sx={{ ...tableBodyCellSx, whiteSpace: "nowrap" }}>
                                    <Stack direction="row" spacing={0.25} justifyContent="flex-end">
                                        <IconButton size="small" title="Ver detalle" sx={accionIconSx} onClick={() => onVer(r)}>
                                            <VisibilityOutlinedIcon fontSize="small" />
                                        </IconButton>
                                        <IconButton size="small" title="Editar" sx={accionIconSx} onClick={() => onEditar(r)}>
                                            <EditOutlinedIcon fontSize="small" />
                                        </IconButton>
                                        <IconButton
                                            size="small"
                                            title="Cambiar estado"
                                            sx={accionIconSx}
                                            onClick={() => onCambiarEstado(r)}
                                        >
                                            <ToggleOnOutlinedIcon fontSize="small" />
                                        </IconButton>
                                        <IconButton
                                            size="small"
                                            title="Eliminar"
                                            sx={{ ...accionIconSx, "&:hover": { color: "error.main", bgcolor: "action.hover" } }}
                                            onClick={() => onEliminar(r)}
                                        >
                                            <DeleteOutlineIcon fontSize="small" />
                                        </IconButton>
                                    </Stack>
                                </TableCell>
                            </TableRow>
                        );
                    })}
                </TableBody>
            </Table>
        </Box>
    );
=======
import { Stack, Typography, IconButton } from '@mui/material'
import { IconEye, IconPencil, IconToggleLeft, IconTrash } from '@tabler/icons-react'
import { DataTable } from '@features/produccion/components/DataTable'
import { StatusBadge } from '@features/produccion/components/StatusBadge'
import { SortHeader } from './SortHeader'
import { formatoCodigo, getEstadoVisual, estadoVisualVariant } from '../utils/proveedoresHelpers'

const celdaSx = { fontSize: 12.5, color: 'text.secondary', whiteSpace: 'nowrap' }

export function ProveedoresTable({ rows, sortKey, sortDir, onSort, onVer, onEditar, onCambiarEstado, onEliminar }) {
  const sortProps = { sortKey, sortDir, onSort }

  const columns = [
    {
      key: 'id',
      header: <SortHeader label="Código" colKey="id" {...sortProps} />,
      accessor: (r) => (
        <Typography sx={{ fontFamily: 'monospace', fontWeight: 600, fontSize: 14, color: 'text.primary' }}>
          {formatoCodigo(r.id)}
        </Typography>
      ),
    },
    {
      key: 'nombre',
      header: <SortHeader label="Nombre empresa" colKey="nombre" {...sortProps} />,
      accessor: (r) => <Typography sx={{ fontSize: 14, color: 'text.primary' }}>{r.nombre}</Typography>,
    },
    {
      key: 'nit',
      header: 'NIT',
      accessor: (r) => <Typography sx={{ ...celdaSx, fontFamily: 'monospace' }}>{r.nit}</Typography>,
    },
    { key: 'nombreContacto', header: 'Contacto', accessor: (r) => <Typography sx={celdaSx}>{r.nombreContacto}</Typography> },
    { key: 'telefono', header: 'Teléfono', accessor: (r) => <Typography sx={celdaSx}>{r.telefono}</Typography> },
    { key: 'email', header: 'Correo', accessor: (r) => <Typography sx={celdaSx}>{r.email}</Typography> },
    {
      key: 'estado',
      header: 'Estado',
      accessor: (r) => {
        const ev = getEstadoVisual(r)
        return (
          <StatusBadge variant={estadoVisualVariant[ev]} dot>
            {ev}
          </StatusBadge>
        )
      },
    },
    {
      key: 'acciones',
      header: '',
      align: 'right',
      accessor: (r) => (
        <Stack direction="row" alignItems="center" justifyContent="flex-end" spacing={0.5}>
          <IconButton size="small" title="Ver detalle" onClick={() => onVer(r)} sx={{ color: 'text.secondary' }}>
            <IconEye size={15} />
          </IconButton>
          <IconButton size="small" title="Editar" onClick={() => onEditar(r)} sx={{ color: 'text.secondary' }}>
            <IconPencil size={15} />
          </IconButton>
          <IconButton size="small" title="Cambiar estado" onClick={() => onCambiarEstado(r)} sx={{ color: 'text.secondary' }}>
            <IconToggleLeft size={15} />
          </IconButton>
          <IconButton size="small" title="Eliminar" onClick={() => onEliminar(r)} sx={{ color: 'error.main' }}>
            <IconTrash size={15} />
          </IconButton>
        </Stack>
      ),
    },
  ]

  return <DataTable columns={columns} data={rows} keyExtractor={(r) => r.id} emptyMessage="Sin proveedores encontrados" />
>>>>>>> a0bd307af696e1bcc5724fb95b6a709de9919996
}
