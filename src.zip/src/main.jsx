import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './app/App.jsx'
import AppProviders from './app/providers/AppProviders.jsx'
import './styles/index.css'

createRoot(document.getElementById('root')).render(
<<<<<<< HEAD
  //<StrictMode>
  <App />
  //</StrictMode>,
=======
  <StrictMode>
    <AppProviders>
      <App />
    </AppProviders>
  </StrictMode>,
>>>>>>> a0bd307af696e1bcc5724fb95b6a709de9919996
)